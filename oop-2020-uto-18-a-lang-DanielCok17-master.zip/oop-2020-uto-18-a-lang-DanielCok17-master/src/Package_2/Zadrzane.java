package Package_2;

public class Zadrzane extends Baliky {
	public Zadrzane() {

		super();
		

	
	}	
	public void Stav_balika(int suma)
	{
		suma += 0;
		System.out.println("Uskladnen�,cena je uskladnenie je " + suma);
	}
	
}
