package Package_2;

public  class Baliky {
	boolean stav;
	int suma = 10;	
	

	public void Stav_balika(int suma)
	{
		suma +=0;
		System.out.println("Stav balika nezn�my!");
	}
}
