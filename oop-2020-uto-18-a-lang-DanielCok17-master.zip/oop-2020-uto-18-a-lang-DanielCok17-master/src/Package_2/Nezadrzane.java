package Package_2;

public class Nezadrzane extends Baliky {

	public Nezadrzane() {
		super();
		
	}
	
	public void Stav_balika(int suma)
	{
		suma += 0;
		System.out.println("Nezadrzany blaik,cena je nezmenena : " + suma);
	}

}
